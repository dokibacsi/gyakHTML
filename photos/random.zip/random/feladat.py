import random


def beker():
    global alsoHatar
    global felsoHatar
    global feladatSzam
    feladatSzam = int(input("Kérlek add meg, mennyi legyen a(z) feladatok száma: "))
    alsoHatar = int(input("Kérlek add meg, mennyi legyen a(z) alsó határ, ami a legkisebb szám lehet: "))
    felsoHatar = int(input("Kérlek add meg, mennyi legyen a(z) felső határ, ami a legnagyobb szám lehet: "))


def kileptetes():

    print("Szeretnél még újra játszani?\n"
          "[I / i]: igen\n"
          "[N / n]: nem")
    dontes = input("Döntésem: ")

    if dontes == "i" or dontes == "I":
        start()
    else:
        print("Köszönöm szépen, hogy játszottál!")

def feladatKivalaszto():
    feladatTipus = int(input(
        "Kérlek add meg, melyik feladattípust szeretnéd:\n"
        "[1]: Összeadás\n"
        "[2]: Kivonás\n"
        "[3]: Szorzás\n"
        "[4]: Osztás\n"
        "Döntésem: "))

    if feladatTipus >= 1 and feladatTipus <= 4:
        if feladatTipus == 1:
            osszeadas()
        elif feladatTipus == 2:
            kivonas()
        elif feladatTipus == 3:
            szorzas()
        else:
            osztas()

def osszeadas():
    beker()

    szamlalo = 0
    while szamlalo != feladatSzam:
        szam1 = random.randint(alsoHatar, felsoHatar)
        szam2 = random.randint(alsoHatar, felsoHatar)

        print("Összeadás:", szam1, "+", szam2)
        eredmeny = int(input(("Eredmény: ")))

        eredmenyEllenorzo = szam1 + szam2

        while eredmeny != eredmenyEllenorzo:
            print("\nAz általad beírt összeg hibás!")
            print("Összeadás:", szam1, "+", szam2)
            eredmeny = int(input(("Eredmény: ")))
        szamlalo += 1
        print("\nGratulálok! Jól számoltál! A ", szam1, "és", szam2, "eredmenyénye:", eredmeny, "\n")

    kileptetes()

def kivonas():
    beker()

    szamlalo = 0
    while szamlalo != feladatSzam:
        szam1 = random.randint(alsoHatar, felsoHatar)
        szam2 = random.randint(alsoHatar, felsoHatar)

        print("Kivonas:", szam1, "-", szam2)
        eredmeny = int(input(("Eredmény: ")))

        eredmenyEllenorzo = szam1 - szam2

        while eredmeny != eredmenyEllenorzo:
            print("\nAz általad beírt összeg hibás!")
            print("Kivonas:", szam1, "-", szam2)
            eredmeny = int(input(("Eredmény: ")))
        szamlalo += 1
        print("\nGratulálok! Jól számoltál! A ", szam1, "és", szam2, "eredmenyénye:", eredmeny, "\n")

    kileptetes()

def szorzas():
    beker()

    szamlalo = 0
    while szamlalo != feladatSzam:
        szam1 = random.randint(alsoHatar, felsoHatar)
        szam2 = random.randint(alsoHatar, felsoHatar)

        print("Szorzas:", szam1, "*", szam2)
        eredmeny = int(input(("Eredmény: ")))

        eredmenyEllenorzo = szam1 * szam2

        while eredmeny != eredmenyEllenorzo:
            print("\nAz általad beírt összeg hibás!")
            print("Szorzas:", szam1, "*", szam2)
            eredmeny = int(input(("Eredmény: ")))
        szamlalo += 1
        print("\nGratulálok! Jól számoltál! A ", szam1, "és", szam2, "eredmenyénye:", eredmeny, "\n")

    kileptetes()


def osztas():
    beker()

    szamlalo = 0
    while szamlalo != feladatSzam:
        szam1 = random.randint(alsoHatar, felsoHatar)
        szam2 = random.randint(alsoHatar, felsoHatar)

        print("Osztas:", szam1, "/", szam2)
        eredmeny = int(input(("Eredmény: ")))

        eredmenyEllenorzo = szam1 / szam2

        while eredmeny != eredmenyEllenorzo:
            print("\nAz általad beírt összeg hibás!")
            print("Osztas:", szam1, "/", szam2)
            eredmeny = int(input(("Eredmény: ")))
        szamlalo += 1
        print("\nGratulálok! Jól számoltál! A ", szam1, "és", szam2, "eredmenyénye:", eredmeny, "\n")

    kileptetes()

def start():
    feladatKivalaszto()
