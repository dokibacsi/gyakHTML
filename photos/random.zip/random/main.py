import feladat

feladat.start()